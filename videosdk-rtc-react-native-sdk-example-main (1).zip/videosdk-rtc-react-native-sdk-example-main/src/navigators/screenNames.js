export const SCREEN_NAMES = {
  Join: "Join_Screen",
  Meeting: "Meeting_Screen",
};
